# Particle Swarm Optimization (PSO) in Python

<p align="center">
    <img src="https://yarpiz.com/wp-content/uploads/2017/08/ypea127-particle-swarm-optimization.jpg" alt="Particle Swarm Optimization (PSO) in Python">
</p>

This is an implementation of Particle Swarm Optimization (PSO) in Python.

For more information, visit following URL:
https://yarpiz.com/463/ypea127-pso-in-python

## Citing This Work
You can cite this code as follows:

**Mostapha Kalami Heris, Particle Swarm Optimization (PSO) in Python (URL: https://yarpiz.com/463/ypea127-pso-in-python), Yarpiz, 2017.**
